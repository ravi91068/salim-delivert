

<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;


function dkim_is_aval($domain){



if(!file_exists("./dkim/".$domain."/mailatmars.private")){






$get_dkim_privat_file= file_get_contents("https://dkim.matmdlvr.com/send/gen_dkim_pri.php?domain=".$domain);

mkdir("./dkim/".$domain,777);

chmod("./dkim/".$domain, 0777);

$myfile = fopen("./dkim/".$domain."/mailatmars.private", "w");
fwrite($myfile,$get_dkim_privat_file);
fclose($myfile);

}
return true;
}

$servername = "154.12.252.26";
$username = "maildb_user";
$password = "Master2016";
$dbname = "list_contacts";

$conn_of_lst = mysqli_connect($servername, $username, $password,$dbname);


function cors() {

    // Allow from any origin
    if (isset($_SERVER['HTTP_ORIGIN'])) {
        // Decide if the origin in $_SERVER['HTTP_ORIGIN'] is one
        // you want to allow, and if so:
        header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
        header('Access-Control-Allow-Credentials: true');
        header('Access-Control-Max-Age: 86400');    // cache for 1 day
    }

    // Access-Control headers are received during OPTIONS requests
    if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
            // may also be using PUT, PATCH, HEAD etc
            header("Access-Control-Allow-Methods: GET, POST, OPTIONS");

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
            header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");

        exit(0);
    }

}

cors();

function httpGet($url)
{

    $ch = curl_init();

    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
//  curl_setopt($ch,CURLOPT_HEADER, false);

    $output=curl_exec($ch);
    curl_close($ch);
    return $output;
}


function httpPost($url,$params)
{


        $postData = '';
   //create name value pairs seperated by &
   foreach($params as $k => $v)
   {
      $postData .= $k . '='.$v.'&';
   }
   $postData = rtrim($postData, '&');

    $ch = curl_init();

    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_POST, count($params));
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);

    $output=curl_exec($ch);

    if (curl_errno($ch)) {
    $error_msg = curl_error($ch);
    }


    curl_close($ch);
    return $output;

}


function update_flg_of_camp_act($conn,$flg,$lst_name,$camp_name,$email){


$update_query_name="update `$lst_name` set `$camp_name`='$flg' where email='$email'";

$conn->query($update_query_name);





}


function unicode2html($str){
    $i=65535;
    while($i>0){
        $hex=dechex($i);
        $str=str_replace("\u$hex","&#$i;",$str);
        $i--;
     }
     return $str;
}








function send_mail_final($row_data,$data_arr,$camp_name,$conn,$lst_name,$track_flg,$auta_flg){




 // print_r($data_arr);

    $frm_mail=$data_arr['to']['frm_email'];
    $frm_name=$data_arr['to']['frm_name'];

   // $prev_fld=$data_arr['tp']['prev_fld'];


    $reply_email=$data_arr['to']['reply_email'];
    $reply_name=$data_arr['to']['reply_name'];
    $email=$row_data['email'];
  $temp_url=$data_arr['to']['template_url'];

  $html_con=(httpGet(urldecode($temp_url)));

  $html_con_of_get=json_decode(rtrim($html_con, "\0"),true);

  $sub_fld=$html_con_of_get['subject_line'];

 $prev_fld=$data_arr['to']['prev_fld'];

  $template=$html_con_of_get['content_for_send'];

  if(isset($data_arr['to']['mrg_fld'])){

  $merg_data=$row_data[$data_arr['mrg_fld']];

  }else{

  $merg_data=$row_data['email'];

  }





  $smtp_host_loc=$data_arr['to']["smtp_host"];
  $smtp_usr_loc=$data_arr['to']["smtp_usr"];
  $smtp_pass_loc=urldecode($data_arr['to']["smtp_pass"]);
  $smtp_port_loc=$data_arr['to']["smtp_port"];
  $attachment_data=$data_arr['to']['attachment'];

print_r($attachment_data);


  require_once "vendor/autoload.php";

  $mail = new PHPMailer(true);
  //Enable SMTP debugging.
$mail->SMTPDebug = 0;
//Set PHPMailer to use SMTP.

//$mail->isSendmail();
$mail->isSMTP(); 
$mail->Host       = 'localhost';                     //Set the SMTP server to send through
    $mail->SMTPAuth   = false;                                   //Enable SMTP authentication
  $mail->Port       = 2525;
//$mail->addCustomHeader('x-virtual-mta', 'pmta-vmta1');
   
$mail->CharSet = 'UTF-8';


$domain_name=explode("@",$frm_mail)[1];

//if(dkim_is_aval($domain_name)){

$mail->DKIM_domain = $domain_name;
//See the DKIM_gen_keys.phps script for making a key pair -
//here we assume you've already done that.
//Path to your private key:
$mail->DKIM_private = "./dkim/".$domain_name."/default.private";
//Set this to your own selector
$mail->DKIM_selector = 'default';
//Put your private key's passphrase in here if it has one
$mail->DKIM_passphrase = '';
//The identity you're signing as - usually your From address
$mail->DKIM_identity = "mail@".$domain_name;
//Suppress listing signed header fields in signature, defaults to true for debugging purpose
$mail->DKIM_copyHeaderFields = false;
//Optionally you can add extra headers for signing to meet special requirements
$mail->DKIM_extraHeaders = ['List-Unsubscribe', 'List-Help'];












 $mail->setFrom($frm_mail,$frm_name);
$mail->From =$frm_mail;
$mail->FromName = $frm_name;
$mail->addReplyTo($reply_email, $reply_name);
$mail->addAddress($email,$merg_data);
//$mail->addCustomHeader("List-Unsubscribe-Post","List-Unsubscribe=One-Click");
$mail->addCustomHeader("List-Unsubscribe","<https://api.mailatmars.com/contact/unsubscribe/mail/".$lst_name."/".$row_data['con_id'].">");
$mail->isHTML(true);


foreach ($attachment_data as $key2 => $value2) {


	print_r($value2);


  $mail->addStringAttachment(file_get_contents($value2['attach_url']), $value2['attch_name']);
#$mail->AddAttachment($value2['attach_url'],$value2['attch_name']);

}


$html_con = '<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /><meta  content="width=device-width, initial-scale=1.0" name="viewport"><div style="display:none;font-size:1px;line-height:1px;max-height:0px;max-width:0px;opacity:0;overflow:hidden;mso-hide:all;font-family: sans-serif;">'.$prev_fld.'</div>'.$template;
$mail->Subject = unicode2html($sub_fld);
$mail->Body = $html_con;
$mail->AltBody = $prev_fld;

try {
    $mail->send();


update_flg_of_camp_act($conn,1,$lst_name,$camp_name,$email);

$con_id=$row_data['con_id'];
} catch (Exception $e) {



update_flg_of_camp_act($conn,-1,$lst_name,$camp_name,$email);

}

}



$postBody = $_GET['data'];

print_r($postBody);
$data_of_req=json_decode($postBody);

$data_of_req = json_decode(json_encode($data_of_req), true);

$lst_name=$data_of_req['list_name'];
$camp_name=$data_of_req['camp_id'];
$row_data=$data_of_req['contact_data'];
$content_data=$data_of_req['content'];
$track_flg=$data_of_req['track_reply'];
$auta_flg=$data_of_req['flg_for_auta'];
send_mail_final($row_data,$content_data,$camp_name,$conn_of_lst,$lst_name,$track_flg,$auta_flg);
mysqli_close($conn_of_lst);
?>
