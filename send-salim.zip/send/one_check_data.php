<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

function get_def_smtp_id($conn,$usr_id){



$sel_smtp_id="select smtp_def from userinfo where id='".$usr_id."'";



$result = $conn->query($sel_smtp_id);



$row = $result->fetch_assoc();


return $row['smtp_def'];


}
function def_smtp_serv($conn,$smtp_id){

$sel_aws_def_acc="select * from smtp_admin_cred where smtp_id='".$smtp_id."'";

$result = $conn->query($sel_aws_def_acc);

$row = $result->fetch_assoc();


//$row['host']=explode(".",$row['host'])[1];

return $row;

}

$servername = "database-2.ctrrqd240l6m.us-east-2.rds.amazonaws.com";
$username = "admin";
$password = "Ravi91068";
$db="smtp_data";


$conn_smtp = mysqli_connect($servername, $username, $password,$db);

$db="signup";
$conn_user=mysqli_connect($servername, $username, $password,$db);


function check_data_of_arr($conn_user,$conn_smtp,$domain,$id){




$smtp_data=def_smtp_serv($conn_smtp,get_def_smtp_id($conn_user,$id));

$smtp_host=$smtp_data['host'];

#echo $smtp_host;

$get_data=json_decode(file_get_contents("http://".$smtp_host."/send/gen_dkim.php?domain=".$domain));

$dkim_val_comp=$get_data->value;
//print_r($get_data);

$array_of_rec_ver=array("mx"=>0,"spf"=>0,"dmarc"=>0,"dkim"=>0,"owner"=>0,"total"=>0);
print_r(dns_get_mx($domain,$mx_details));

if(dns_get_mx($domain,$mx_details)){
  foreach($mx_details as $key=>$value){

if($value==$smtp_host){
$array_of_rec_ver['mx']=1;
$array_of_rec_ver['total']+=1;
}

  }
}
$txt_record=dns_get_record($domain, DNS_TXT);

print_r($txt_record);
foreach ($txt_record as $key => $value) {

if(strpos($value['entries'][0], ' mx ') !== false && strpos($value['entries'][0], '~all') !== false){
$array_of_rec_ver['spf']=1;
$array_of_rec_ver['total']+=1;
}

}

$owner_code=base64_encode($id."#".$domain);

echo $owner_code;

$txt_record=dns_get_record("mailatmars.com.".$domain,DNS_TXT);

print_r($txt_record);
if($txt_record[0]['entries'][0]==$owner_code){
  $array_of_rec_ver['owner']=1;
  $array_of_rec_ver['total']+=1;
}

$txt_record=dns_get_record("mailatmars._domainkey.".$domain,DNS_TXT);


print_r($txt_record);
$key_dns=$txt_record[0]['txt'];



//print_r($dkim_val_comp==$key_dns);
if(strpos($dkim_val_comp, $key_dns) !== false){
	
	echo "match";
	$array_of_rec_ver['dkim']=1;
$array_of_rec_ver['total']+=1;
}

$txt_record=dns_get_record("_dmarc.".$domain,DNS_TXT);



foreach ($txt_record as $key => $value) {
	
	//	print_r($value)
	//	;
	//
	//print_r($value);
	$compar_key=$value['entries'][0];
	if($compar_key=="v=DMARC1; p=none; pct=100; fo=1; rua=mailto:dmarc-reports@matmdlvr.com"){
  $array_of_rec_ver['dmarc']=1;
  $array_of_rec_ver['total']+=1;
}
}

print_r($array_of_rec_ver);

if($array_of_rec_ver['total']>=3){

$update_query="update sender_data set var_flag='3' where id='$id' and email='$domain'";

echo $update_query;
$conn_user->query($update_query);

}else{
  $update_query="update sender_data set var_flag='0' where id='$id' and email='$domain'";

  echo $update_query;
  $conn_user->query($update_query);
}

}


$email=$_GET['domain'];
$id=$_GET['id'];


check_data_of_arr($conn_user,$conn_smtp,$email,$id);
  
 ?>

