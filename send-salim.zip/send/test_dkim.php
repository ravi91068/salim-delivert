<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

function dkim_is_aval($domain){



if(!file_exists("./dkim/".$domain."/mailatmars.private")){






$get_dkim_privat_file= file_get_contents("https://dkim.matmdlvr.com/send/gen_dkim_pri.php?domain=".$domain);

mkdir("./dkim/".$domain,777);

chmod("./dkim/".$domain, 0777);
$myfile = fopen("./dkim/".$domain."/mailatmars.private", "w");
fwrite($myfile,$get_dkim_privat_file);
fclose($myfile);

}

chmod("./dkim/".$domain, 0777);
return true;
}



 dkim_is_aval($_GET['domain']);

?>
